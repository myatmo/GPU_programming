#include <stdlib.h> 
#include <string.h> 
#include <stdio.h> 
#include <mpi.h>
#include <math.h>

int HQuicksort(int *Abuf, int *lenA,  int *list, int N, MPI_Comm comm) {
/*--------------------    
 Most of  the lab2  assignment will consist  of writing  this function.
 Right now,  it is set  to just print ``nothing  done" and exit.  It is
 provided so you can compile and run the pgm - but the numbers will not
 be sorted.
-------------------- */
  printf(" nothing done \n");
  return(0);
    }
